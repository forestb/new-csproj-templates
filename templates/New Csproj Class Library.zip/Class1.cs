﻿using System;

namespace $safeprojectname$
{
    public class Class1
    {
    }
}
